package com.sat.testUtil;

public class Log {

	public static void info(String userName) {
		// TODO Auto-generated method stub
		
	}

}
